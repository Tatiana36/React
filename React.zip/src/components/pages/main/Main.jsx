import { useState, useEffect } from 'react'


export function Main () {



    return (
        <>
            <h1>Welcome to HOME!</h1>
        </>
    )
}

// export default App