export const AUTHOR = {
    user: 'user',
    bot: 'bot'
}

